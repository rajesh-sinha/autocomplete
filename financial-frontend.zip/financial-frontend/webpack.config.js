var webpack = require('webpack');
var path = require('path');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var fs = require('fs');


var extractPropExtractorLess = new ExtractTextPlugin('propextractor-styles.css');

const appsPath = path.resolve('../../../../applications/CIQDotNet/Financial/libs');
const outputPath = fs.existsSync(appsPath) ? appsPath : path.resolve(__dirname, 'dist');

const loadersForLess = {
  use: [
    'css-loader',
    'less-loader'
  ],
}

module.exports = {
  resolve: {
    modules: [ path.resolve(__dirname), path.resolve(__dirname, "node_modules") ],
    alias: {
      shared: path.resolve(__dirname, "sharedJs"),
      charts: path.resolve(__dirname, "charts"),
      'datatables.net': './datatables.js',
    }
  },
  entry: {
    propExtractor: './PropExtractor/propextractorliberary-main.tsx'
  },
  output: {
    path: outputPath,
    filename: "[name].bundle.js",
    libraryTarget: "var",
    library: "[name]_lib"
  },
  // devtool: 'cheap-source-map',
  module: {
    loaders: [
    {
      test: /PropExtractorStyling\.less$/,
      include: [
        path.resolve(__dirname, "PropExtractor/styling")
      ],
      loader: extractPropExtractorLess.extract(loadersForLess)
  },
      {
        test: /\.(gif|woff|woff2|svg|png|ttf|eot|otf)$/,
        loader: 'file-loader',
        options: {
            name: 'assets/[name]-[hash].[ext]'
        }
      },
      {
        test: /\.handlebars$/,
          loader: 'handlebars-loader',
          options: {
              helperDirs: [
                  __dirname + "/handlebarsHelpers"
              ],
              preventIndent: true
          }
      },
      { test: /jquery-mousewheel/, loader: "imports-loader?define=>false&this=>window" },
			{ test: /malihu-custom-scrollbar-plugin/, loader: "imports-loader?define=>false&this=>window" },      
      {
        test: /\.js$/,
        exclude: /node_modules|ciq-charts-0.5.0|jquery-ui|datatables|select2|widgetQuickInfo|libs\\/,
        use: [
          {
            loader: 'babel-loader',
            options: {
              cacheDirectory: true
            }
          },
          {
            loader: 'eslint-loader',
            options: {
              cache: true,
              fix: true
            }
          },
        ]
      },
      {
        test:/\.tsx?$/,
        exclude :/node_modules|ciq-charts-0.5.0|jquery-ui|datatables|select2|widgetQuickInfo|libs\\/,
        use: [
          {
            loader: 'babel-loader',
            options: {
              cacheDirectory: true
            }
          }
        ]
        
      },
      {
        test: /\.js$/,
        exclude: /node_modules|ciq-charts-0.5.0|jquery-ui|datatables|select2|widgetQuickInfo|libs\\/,
      },
      {
        test: /\.html$/,
        loader: 'html-loader',
        options: {
          interpolate: true
        }
      },
      
    ]
  },
  plugins: [
    new webpack.ProvidePlugin({
      $: 'jquery',
      jQuery: 'jquery',
      'window.jQuery': 'jquery'
    }),
    extractPropExtractorLess
  ]
};
