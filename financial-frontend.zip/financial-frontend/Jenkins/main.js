const azdev = require('azure-devops-node-api'),
      AdmZip = require('adm-zip'),
      runCmd = require('../scripts/run'),
      path = require('path'),
      util = require('util'),
      execPromise = util.promisify(require('child_process').exec);

const [,,token,svnUsername,svnPassword,branchName,needsBugId] = process.argv;

if (!token || !svnUsername || !svnPassword || !branchName) {
  console.error('Usage: node main <token> <svnuser> <svnpassword> <branch> [--bug-id]');
  process.exit(1);
}

const maxTimeForSvnCmd = 80000;
const maxSvnRetries = 5;
const retryDelay = 180000; // 3 min
const maxRetries = 5; // it doesn't usually take more than 15 minutes for Azure to publish the build data through the api
const orgUrl = 'https://dev.azure.com/spglobal';
const project = '2e66309d-fc7e-4335-94fe-a32f3f10c35a'; // Credit Analytics
const repositoryId = 'a5583140-aac6-4d2e-b5f9-766e166453cb'; // ca-frontend
const repositoryType = 'TfsGit';
const artifactName = 'artifacts';

const authHandler = azdev.getPersonalAccessTokenHandler(token);
const connection = new azdev.WebApi(orgUrl, authHandler);

const queryOrder = 'finishTimeDescending';
const statusFilter = 'completed';
const resultFilter = 'succeeded';
const top = 1;
const {definitions, queues, buildNumber, minTime, maxTime, requestedFor, reasonFilter, tagFilters, properties, continuationToken, maxBuildsPerDefinition, deletedFilter, buildIds} = {};

const outputPath = path.resolve(__dirname, '../dist') // this is both where we have checked out SVN to and where webpack.config.js will output to if the regular applications folder path doesn't exist

// Direct API URLs, for reference:
//   https://dev.azure.com/spglobal/Credit%20Analytics/_apis/build/builds?api-version=5.0&repositoryType=TfsGit&repositoryId=a5583140-aac6-4d2e-b5f9-766e166453cb&resultFilter=succeeded&statusFilter=completed&queryOrder=finishTimeDescending&$top=1
//   https://dev.azure.com/spglobal/Credit%20Analytics/_apis/build/builds/538212/artifacts?artifactName=artifacts&api-version=5.0&$format=zip

// Uncomment this if you can't run it and want to ignore HTTPS cert fails (though, it doesn't seem to work on my box):
// process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

let headHash = null
let headHashTime = null

async function tryFetchAndCommit(attemptCount = 0) {
  const retry = async () => {
    if (attemptCount >= maxRetries) {
      throw new Error('Too many unsuccessful retries. Failing build.')
    }
    console.log(`Retrying fetch (retry #${attemptCount+1}) in ${retryDelay}ms...`)
    await new Promise(resolve => setTimeout(resolve, retryDelay))
    return tryFetchAndCommit(attemptCount + 1)
  }

  const runSvn = async (cmd, svnopts, svnAttemptCount = 0) => {
    let isKilled = false
    const timer = setTimeout(() => {
      isKilled = true
      try {
        runCmd('powershell -Command "Stop-Process -Name svn"')
      } finally {
        runCmd(`svn cleanup ${outputPath} ${svnopts}`)
      }
    }, maxTimeForSvnCmd)

    try {
      const {stdout, stderr} = await execPromise(cmd, { encoding: 'utf8', stdio: ['inherit', 'pipe', 'inherit'] });

      if (stdout) {
        console.log(stdout);
      }
      if (stderr) {
        console.error(stderr);
      }
      clearTimeout(timer)
    } catch (e) {
      if (isKilled) {
        if (svnAttemptCount >= maxSvnRetries) {
          throw new Error('Too many unsuccessful svn retries. Failing build.')
        }

        console.log(`Retrying (retry #${svnAttemptCount+1})...`)
        await runSvn(cmd, svnopts, svnAttemptCount + 1)
      }
      else {
        clearTimeout(timer)
        throw e
      }
    }
  }

  try {
    const build = await connection.getBuildApi(project);
    const bs = await build.getBuilds(project, definitions, queues, buildNumber, minTime, maxTime, requestedFor, reasonFilter, statusFilter, resultFilter, tagFilters, properties, top, continuationToken, maxBuildsPerDefinition, deletedFilter, queryOrder, branchName, buildIds, repositoryId, repositoryType);

    if (bs && bs.length) {
      const b = bs[0];
      console.log('Retrieving artifacts...\n');
      console.log(`Build id: ${b.id}`);
      console.log(`Branch: ${b.sourceBranch}`);
      console.log(`Commit hash: ${b.sourceVersion}`);
      console.log(`Requested for: ${b.requestedFor.displayName}`);
      console.log(`Finished time: ${b.finishTime}`);

      if (headHash === null) { // only do this once (if we have to retry)
        headHash = runCmd(`git rev-parse head`)
        headHashTime = runCmd(`git show -s --format=%ct ${headHash}`)
      }

      if (headHash !== b.sourceVersion) {
        const buildHashTime = runCmd(`git show -s --format=%ct ${b.sourceVersion}`)

        if (buildHashTime < headHashTime) {
          console.log(`Latest build for ${branchName} not yet available.`)
          await retry()
          return
        }
      }

      const workItem = await build.getBuildWorkItemsRefs(project, b.id, 1); // top=1
      let includedBugIdShim = '';

      if (workItem && workItem.length > 0) {
        includedBugIdShim = `BugId : ${workItem[0].id}   ` //Note: could be a user story, task, etc. Oh well.
        console.log(`Work item: ${workItem[0].id}`)
      }
      else if (needsBugId) {
        includedBugIdShim = 'BugId : 0   '
      }

      const data = await build.getArtifactContentZip(bs[0].id, artifactName, project);
      let buf;

      data.on('readable', function() {
        // there is some data to read now
        let data2;

        while (data2 = this.read()) {
          if (!buf) {
            buf = data2;
          }
          else {
            buf = Buffer.concat([buf, data2]);
          }
        }
      });

      data.on('close', () => {
        const zip = new AdmZip(buf);
        const svnopts = `--username ${svnUsername} --password ${svnPassword} --no-auth-cache --non-interactive`;

        const doSvn = async () => {
          await runSvn(`svn up --accept theirs-full ${svnopts} ${outputPath}`, svnopts)

          zip.getEntries().forEach(entry => {
            if (!entry.isDirectory) {
              const entryPath = entry.entryName.slice(0, -entry.name.length);
              const newSubPath = entryPath && entryPath !== 'artifacts/' ? entryPath.match(/^artifacts\/(.+)$/)[1] : '';

              zip.extractEntryTo(entry, path.join(outputPath, newSubPath), false, true);
            }
          })

          return runSvn(`svn commit ${outputPath} -m "${includedBugIdShim}${includedBugIdShim ? ' ' : ''}Git revision ${b.sourceVersion} in ${b.sourceBranch}" ${svnopts}`, svnopts)
        }

        try {
          doSvn().then(() => console.log('\nDone.'))
        } catch (e) {
          console.error(e);
          process.exit(1);
        }
      });
    }
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
}

tryFetchAndCommit()
