import React, { Fragment, useState } from "react";
import "../styling/PropExtractorStyling.less";

class UploadFile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {fileName : "No file chosen"}
  }

  _handleImageChange(e) {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];
    // useState({
    //   fileName : e.target.files[0].name
    // })

    reader.onloadend = () => {
      const obj_url = window.URL.createObjectURL(file);
      const iframe = document.getElementById("pdf-viewer");
      iframe.setAttribute("src", obj_url);
      window.URL.revokeObjectURL(obj_url);
      
    };
    reader.readAsDataURL(file);
  }

  render() {
    return (
      // <div  class="image-upload">
      //     <label for="file-input">
      //     <img src="/ciqdotnet/images/Bindertoolbar/ico_saveScreenImage.gif"/>
      //     <span id="file-name" class="file-box">{this.state.fileName}</span>
      // </label>

      //   <input
      //    id="file-input"
      //     type="file"
      //     onChange={e => this._handleImageChange(e)}
      //   />
      // </div>

      //////////////////////////////////////////////////
      // <Fragment>
      //   <div class="inputfile-box">
      //     <label for="file">
      //       <span class="file-button">
      //         <img src="/ciqdotnet/images/widget/bug.png" />
      //       </span>
      //       <span id="file-name" class="file-box"></span>
      //     </label>
      //     <input
      //       id="file"
      //       class="inputfile"
      //       type="file"
      //       onChange={e => this._handleImageChange(e)}
      //     />
      //   </div>
      // </Fragment>

      <div className="formStyle">
          <input className="file-box"
         id="file-input"
          type="file"
          onChange={e => this._handleImageChange(e)}
        />
      </div>
    );
  }
}
export default UploadFile;
