import React, { Fragment, useState } from "react";
import "../styling/PropExtractorStyling.less";

export default class UploadFile_copy extends React.Component {
  state = {
    items: ['nnb','bb'],
    suggestions: []
  }


onTextChanged(e){
  const value = e.target.value;
  let suggestions = [];
  if(value.length > 0) {
      const regex = new RegExp(`^${value}`, 'i');
      suggestions = this.state.items.sort().filter(v => regex.test(v));
  }
  this.setState(() =>({ suggestions }));
}
    renderSuggestions() {
      const { suggestions } = this.state;
      if(suggestions.length === 0){
          return null;
      }
      return (
          <div><ul>
            suggestions.map(item => <li> {this.state.items}</li>)
          </ul>
          </div>
      )
    }

    render() {
        return (
            <div>
            <input onChange = {this.onTextChanged} type = "text"/>
            {this.renderSuggestions()}
            </div>
        )
      }
  }
