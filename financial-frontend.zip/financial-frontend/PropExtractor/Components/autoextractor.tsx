import React, { Fragment } from 'react';
import LeftHandControl from './lefthandcontrol.tsx';
import DetailsControl from './DetailsControl.tsx';
import  '../styling/PropExtractorStyling.less';

const AutoExtractor = () => {
    return (
        <Fragment>
        
        {/* <div className="row"> */}
        <div className="column left">
              <LeftHandControl />
        </div>
        <div className="column right" >
             <DetailsControl />
        </div>
      {/* </div> */}
     
      </Fragment>

    )
}

export default AutoExtractor;