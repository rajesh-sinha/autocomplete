import React from "react";
import  '../styling/PropExtractorStyling.less';

interface state {
  name : Array<any>
}

interface props {
  ModelType : object
}

class ExtractionModel extends React.Component<props,state> {
 
  constructor(props){
    
    super(props);
    this.state = {name : Object.values(props.ModelType)}

  }

  

  // componentDidMount(){
  //     this.setState({
  //       name : [
  //         {id : 1 , dropDownValue : 'Credit Model 1'},
  //         {id : 2 , dropDownValue : 'PD Model 2'},
  //         {id : 3 , dropDownValue : 'FS Model 3'}
  //       ]
  //     })
  // }

  render() {

  //  const { dropDownName } = this.state;
      
    let dropDownList = this.state.name.length > 0 && this.state.name.map((item,i) => {

      return (
        <option key = {i} value = {i} >{item}</option>
      )

    },this);

    return (
      // <form>
      //   <select>
      //     <option value="1">Credit Model</option>
      //     <option value="2">PD Model</option>
      //     <option value="3">FS Model</option>
      //   </select>
      // </form>
      <form className="formStyle">
        <select className="dropDown">
        {dropDownList}
        </select>
      </form>
    );
  }
}

 export default ExtractionModel;
