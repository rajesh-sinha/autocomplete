import React from 'react';
import ExtractionModel from './extractionmodel.tsx';
import UploadFile from './uploadFile.tsx';
import  '../styling/PropExtractorStyling.less';
import UploadFile_copy from './uploadFile_copy.tsx';

const Models = {
   1 : 'Credit Model',
   2 : 'PD Model',
   3 : 'FS Model'
}

const Languages = {
    1 : 'Hindi',
    2 : 'English',
    3 : 'Bengali'
 }

const LeftHandControl = () => {

    return (
    <React.Fragment>
          <p>Extraction Model</p>  <ExtractionModel ModelType = {Models} />
          <p>Language</p>  <ExtractionModel ModelType = {Languages} />
          <p>Upload Document</p> <UploadFile />  
          <p>Company Search</p><UploadFile_copy/>


    </React.Fragment>
    )

}

export default LeftHandControl;