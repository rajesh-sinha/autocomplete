import React from "react";
import  '../styling/PropExtractorStyling.less';

const DetailsControl = () => {

    return (
        <React.Fragment>
            {/* <div className = "detailsInnerTopdiv">
                {/* <p className="iframeHeading">Table View</p> */}
             {/* <div>Table View<iframe id="pdf-viewer" className='rightiframeSpan'></iframe></div>  

             {/* <p className="iframeHeading">Document View</p>   */}
             {/* <div>Document View<iframe id="extracted-viewer" className="leftiframeSpan"></iframe></div>    
             </div>
             <div className = "detailsInnerBottompdiv">
             </div>     */} 

                         <div className = "detailsInnerTopdiv">
               <table>
                   <tbody>
                       <tr>
                           <th className="leftIframeHeading">Table View</th>
                           <th className="rightiframeHeading">Document View</th>
                       </tr>
                       <tr>
                           <td><iframe id="extracted-viewer" className="leftiframeSpan"></iframe></td>
                           <td> <iframe id="pdf-viewer" className='rightiframeSpan'></iframe></td>
                       </tr>
                   </tbody>
            </table>  
             </div>
             <div className = "detailsInnerBottompdiv">
             </div>  
             </React.Fragment>
    )

}

export default DetailsControl;
