import  React from "react";
import ReactDOM from "react-dom";
import AutoExtractor from './Components/autoextractor.tsx';




const renderPropExtractorLibrary = () => {

     $(document).ready(() => {


    ReactDOM.render(<AutoExtractor />, document.querySelector('.js-app-container'));

  });
};



export default {
  $,
  renderPropExtractorLibrary : renderPropExtractorLibrary()
};




