/*
Script to run a full prod build and commit the bundled files to SVN. This should be run after the pull request has successfully completed.

Usage
  npm run build-and-deploy [bug ID | commit message] [commit message]

Bug ID and commit message are optional, and they only appear in the SVN log message. The purpose of these parameters is to make SVN commit messages more verbose and useful.
If you have more than 1 bug ID, just put them in the commit message.

Examples
  npm run build-and-deploy
  npm run build-and-deploy 12345
  npm run build-and-deploy "Adds new column to watchlist"
  npm run build-and-deploy 12345 "Fixes the bug"


Notes
  - friendly reminder that the commit message *must* be contained within "double quotes", not 'single quotes'
  - without a given bug id, the SVN message still contains "BugID : 0" because the RC branch requires a bug id to be explicitly defined
*/

const run = require('./scripts/run'),
      path = require('path')

const outputPath = path.join('..', '..', '..', '..', 'applications', 'CIQDotNet', 'Financial', "libs")
const rcBranchName = 'releases/2019-07'

run(`svn up --accept theirs-full ${outputPath}`)
const stashed = run('git stash')

const currentBranch = run('git rev-parse --abbrev-ref HEAD')

const svnurl = run(`svn info ${outputPath} | findstr /b URL:`)
let destination = ''

if (svnurl.indexOf('/trunk/') > -1) {
  run('git fetch origin master')
  run('git reset --hard origin/master')
  destination = 'trunk'
} else if (svnurl.indexOf('/branches/RC/') > -1) {
  run(`git fetch origin ${rcBranchName}`)
  run(`git reset --hard origin/${rcBranchName}`)
  destination = 'RC'
} else {
  console.log('Looks like we could not find the svn location to commit.')
  return false
}


run('npm install')

const currentHead = run('git rev-parse HEAD') // Should be current hash

run('npm run prod-build')
run('npm run prod-build-export')


const [ arg1, arg2 ] = process.argv.slice(2)
const bugId = parseInt(arg1) || 0
const commitMessage = !parseInt(arg1) ? arg1 : arg2 || null

const commitCommand = `svn commit ${outputPath} -m "BugId : ${bugId} - Git revision ${currentHead} ${commitMessage ? '(' + commitMessage + ') ' : ''}committed to ${destination}"`
run(commitCommand)

run(`git checkout ${currentBranch}`)

if (stashed && !stashed.includes('No local changes to save')) {
  run('git stash pop')
}
