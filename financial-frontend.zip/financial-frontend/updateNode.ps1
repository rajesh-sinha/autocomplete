$ErrorActionPreference = "Stop"

$modulesFolderPath = "node_modules"
$backupFolderPath = "node_modules_backup"

# save off the old folder of node modules
Rename-Item $modulesFolderPath $backupFolderPath

$backupFolder = Resolve-Path $backupFolderPath

# re-download everything into node_modules
& 'npm' 'install'

$modulesFolder = Resolve-Path $modulesFolderPath

# now comes the diff...
$newItems = Get-ChildItem $modulesFolder -Directory
$oldItems = Get-ChildItem $backupFolder -Directory
$newItemNames = $newItems | foreach { $_.Name }
$oldItemNames = $oldItems | foreach { $_.Name }

# first, copy over the .svn folders from anywhere we have a corresponding subfolder
$svns = Get-ChildItem $backupFolder ".svn" -Force -Recurse -Directory | foreach { $_.parent.FullName }
$dirDeletes = New-Object System.Collections.ArrayList
$count = 0
foreach ($svn in $svns) {
    $newSvn = $svn.Replace($backupFolderPath, $modulesFolderPath)
    if (!(Test-Path $newSvn\.svn)) {
        if (Test-Path $newSvn) {
            $subpath = if ($newSvn.length -eq $modulesFolder.Path.length) { $newSvn } else { $newSvn.substring($modulesFolder.Path.length+1) }
            write-host "Copying: $($subpath)"
            Copy-Item "$($svn)\.svn" $newSvn -recurse
        }
        else {
            # just add to a counter to avoid output
            $count += $dirDeletes.add($svn)
        }
    }
}

# next, for each folder that no longer exists, "svn delete" it
foreach ($del in $dirDeletes) {
    $supers = $dirDeletes | Where-Object { $del.startsWith("$($_)\") }
    if ($supers.count -eq 0) {
        $newDir = $del.Replace($backupFolderPath, $modulesFolderPath)
        $outputsink = New-Item $newDir -itemtype directory
        Copy-Item $del\* $newDir -recurse -force
        $subpath = $newDir.substring($modulesFolder.Path.length+1)
        write-host "SVN Deleting: $($subpath)" -foregroundcolor "DarkRed"
        & 'svn' 'delete' $newDir

        <# TODO: the following is commented out because deleting the subfolders (for purposes of "svn add") causes it to be "conflicted" upon next update. if/when we do an auto "svn add" (see below), we might need to re-enable this
        # need to delete any subfolders that still exist, because svn marks them as replaced or something
        $subfolders = Get-ChildItem $newDir -Directory -Force -Recurse | where-object { -Not($_.fullname -like "*\.svn\*") -and -not($_.name -eq ".svn") } | foreach { $_.FullName }
        foreach ($subfo in $subfolders) {
            $subsupers = $subfolders | Where-Object { $subfo.startsWith("$($_)\") }
            if ($subsupers.count -eq 0) {
                Remove-Item $subfo -force -recurse
            }
        }
        #>
    }
}

# for any files that have been deleted from folders that have not, "svn delete" them
$files = Get-ChildItem $backupFolder -Force -Recurse -File -exclude *.svn-base | Where-Object { -Not ($_.FullName -like "*\.svn\*" )} | foreach { $_.FullName }
foreach ($file in $files) {
    $newFile = $file.Replace($backupFolderPath, $modulesFolderPath)
    $oldParent = Split-Path $file -parent
    if (!(Test-Path $newFile) -And ($oldParent -NotIn $dirDeletes)) {
        $subpath = $newFile.substring($modulesFolder.Path.length+1)
        write-host "SVN Deleting: $($subpath)" -foregroundcolor "DarkRed"
        Copy-Item $file $newFile -force
        & 'svn' 'delete' $newFile
    }
}

# TODO: this is commented out because it doesn't currently work for things for which we already marked "svn delete" (it makes them show as "replaced" status); so, mark adds manually until code is written to compensate for this case
# then, for each file that is new, "svn add" it
#& 'svn' 'add' "$($modulesFolder)\*" '--force'

# Finally, clean up after ourselves
write-host "Cleaning up..."
Remove-Item $backupFolder -force -recurse

write-host "Done"