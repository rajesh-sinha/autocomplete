const exec = require('child_process').execSync,
      path = require('path')

module.exports = path => {
    console.log(`\n${path}`)
    let current = exec(path,
        {
          encoding: 'utf8',
          stdio: ['inherit', 'pipe', 'inherit']
        }
    )

    if (current) {
      current = current.toString('utf8')
    }

    console.log(current)

    return current
}
